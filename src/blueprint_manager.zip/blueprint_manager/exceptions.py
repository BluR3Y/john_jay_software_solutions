class ConfigError(Exception):
    pass


class SourceError(Exception):
    pass


class TransformError(Exception):
    pass


class ExportError(Exception):
    pass